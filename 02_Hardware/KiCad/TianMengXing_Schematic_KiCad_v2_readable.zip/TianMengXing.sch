EESchema Schematic File Version 4
LIBS:TianMengXing-cache
EELAYER 30 0
EELAYER END
$Descr A2 23386 16535
encoding utf-8
Sheet 1 1
Title "小车拓展板天猛星2026"
Date "2026-04-18"
Rev "V1.0"
Comp "PDF reverse-created import scaffold"
$EndDescr
Text Notes 700 450 0    100  ~ 0
主控与扩展排针

$Comp
L TianMengXing:MODULE_80 U6
U 1 1 5F000001
P 1700 1450
F 0 "U6" H 1700 1230 50  0000 C CNN
F 1 "LCKFB-TMX-MSPM0G3507" H 1700 1670 50  0000 C CNN
F 2 "" H 1700 1450 50  0001 C CNN
F 3 "" H 1700 1450 50  0001 C CNN
	1    1700 1450
	1    0    0    -1
$EndComp

Wire Wire Line
	1200 -2500 1400 -2500

Text Label 1200 -2500 0    50   ~ 0
GND

Wire Wire Line
	1200 -2400 1400 -2400

Text Label 1200 -2400 0    50   ~ 0
GND

Wire Wire Line
	1200 -2300 1400 -2300

Text Label 1200 -2300 0    50   ~ 0
A00

Wire Wire Line
	1200 -2200 1400 -2200

Text Label 1200 -2200 0    50   ~ 0
A28

Wire Wire Line
	1200 -2100 1400 -2100

Text Label 1200 -2100 0    50   ~ 0
A01

Wire Wire Line
	1200 -2000 1400 -2000

Text Label 1200 -2000 0    50   ~ 0
A31

Wire Wire Line
	1200 -1900 1400 -1900

Text Label 1200 -1900 0    50   ~ 0
A08

Wire Wire Line
	1200 -1800 1400 -1800

Text Label 1200 -1800 0    50   ~ 0
B04

Wire Wire Line
	1200 -1700 1400 -1700

Text Label 1200 -1700 0    50   ~ 0
A09

Wire Wire Line
	1200 -1600 1400 -1600

Text Label 1200 -1600 0    50   ~ 0
B05

Wire Wire Line
	1200 -1500 1400 -1500

Text Label 1200 -1500 0    50   ~ 0
B15

Wire Wire Line
	1200 -1400 1400 -1400

Text Label 1200 -1400 0    50   ~ 0
A10

Wire Wire Line
	1200 -1300 1400 -1300

Text Label 1200 -1300 0    50   ~ 0
B16

Wire Wire Line
	1200 -1200 1400 -1200

Text Label 1200 -1200 0    50   ~ 0
A11

Wire Wire Line
	1200 -1100 1400 -1100

Text Label 1200 -1100 0    50   ~ 0
B02

Wire Wire Line
	1200 -1000 1400 -1000

Text Label 1200 -1000 0    50   ~ 0
B12

Wire Wire Line
	1200 -900 1400 -900

Text Label 1200 -900 0    50   ~ 0
B03

Wire Wire Line
	1200 -800 1400 -800

Text Label 1200 -800 0    50   ~ 0
B13

Wire Wire Line
	1200 -700 1400 -700

Text Label 1200 -700 0    50   ~ 0
DIO

Wire Wire Line
	1200 -600 1400 -600

Text Label 1200 -600 0    50   ~ 0
CLK

Wire Wire Line
	1200 -500 1400 -500

Text Label 1200 -500 0    50   ~ 0
GND

Wire Wire Line
	1200 -400 1400 -400

Text Label 1200 -400 0    50   ~ 0
B07

Wire Wire Line
	1200 -300 1400 -300

Text Label 1200 -300 0    50   ~ 0
B06

Wire Wire Line
	1200 -200 1400 -200

Text Label 1200 -200 0    50   ~ 0
5V

Wire Wire Line
	1200 -100 1400 -100

Text Label 1200 -100 0    50   ~ 0
B08

Wire Wire Line
	1200 0 1400 0

Text Label 1200 0 0    50   ~ 0
B26

Wire Wire Line
	1200 100 1400 100

Text Label 1200 100 0    50   ~ 0
A12

Wire Wire Line
	1200 200 1400 200

Text Label 1200 200 0    50   ~ 0
B09

Wire Wire Line
	1200 300 1400 300

Text Label 1200 300 0    50   ~ 0
B23

Wire Wire Line
	1200 400 1400 400

Text Label 1200 400 0    50   ~ 0
A13

Wire Wire Line
	1200 500 1400 500

Text Label 1200 500 0    50   ~ 0
B27

Wire Wire Line
	1200 600 1400 600

Text Label 1200 600 0    50   ~ 0
GND

Wire Wire Line
	1200 700 1400 700

Text Label 1200 700 0    50   ~ 0
AGND

Wire Wire Line
	1200 800 1400 800

Text Label 1200 800 0    50   ~ 0
3V3

Wire Wire Line
	1200 900 1400 900

Text Label 1200 900 0    50   ~ 0
CHIP

Wire Wire Line
	1200 1000 1400 1000

Text Label 1200 1000 0    50   ~ 0
5V

Wire Wire Line
	1200 1100 1400 1100

Text Label 1200 1100 0    50   ~ 0
A29

Wire Wire Line
	1200 1200 1400 1200

Text Label 1200 1200 0    50   ~ 0
3V3

Wire Wire Line
	1200 1300 1400 1300

Text Label 1200 1300 0    50   ~ 0
GND

Wire Wire Line
	1200 1400 1400 1400

Text Label 1200 1400 0    50   ~ 0
5V

Wire Wire Line
	1200 1500 1400 1500

Text Label 1200 1500 0    50   ~ 0
5V

Wire Wire Line
	1200 1600 1400 1600

Text Label 1200 1600 0    50   ~ 0
A18

Wire Wire Line
	1200 1700 1400 1700

Text Label 1200 1700 0    50   ~ 0
GND

Wire Wire Line
	1200 1800 1400 1800

Text Label 1200 1800 0    50   ~ 0
B14

Wire Wire Line
	1200 1900 1400 1900

Text Label 1200 1900 0    50   ~ 0
GND

Wire Wire Line
	1200 2000 1400 2000

Text Label 1200 2000 0    50   ~ 0
B01

Wire Wire Line
	1200 2100 1400 2100

Text Label 1200 2100 0    50   ~ 0
GND

Wire Wire Line
	1200 2200 1400 2200

Text Label 1200 2200 0    50   ~ 0
A07

Wire Wire Line
	1200 2300 1400 2300

Text Label 1200 2300 0    50   ~ 0
B11

Wire Wire Line
	1200 2400 1400 2400

Text Label 1200 2400 0    50   ~ 0
B22

Wire Wire Line
	1200 2500 1400 2500

Text Label 1200 2500 0    50   ~ 0
RST

Wire Wire Line
	1200 2600 1400 2600

Text Label 1200 2600 0    50   ~ 0
GND

Wire Wire Line
	1200 2700 1400 2700

Text Label 1200 2700 0    50   ~ 0
B00

Wire Wire Line
	1200 2800 1400 2800

Text Label 1200 2800 0    50   ~ 0
3V3

Wire Wire Line
	1200 2900 1400 2900

Text Label 1200 2900 0    50   ~ 0
B10

Wire Wire Line
	1200 3000 1400 3000

Text Label 1200 3000 0    50   ~ 0
B18

Wire Wire Line
	1200 3100 1400 3100

Text Label 1200 3100 0    50   ~ 0
A27

Wire Wire Line
	1200 3200 1400 3200

Text Label 1200 3200 0    50   ~ 0
A23

Wire Wire Line
	1200 3300 1400 3300

Text Label 1200 3300 0    50   ~ 0
A30

Wire Wire Line
	1200 3400 1400 3400

Text Label 1200 3400 0    50   ~ 0
A21

Wire Wire Line
	1200 3500 1400 3500

Text Label 1200 3500 0    50   ~ 0
GND

Wire Wire Line
	1200 3600 1400 3600

Text Label 1200 3600 0    50   ~ 0
A15

Wire Wire Line
	1200 3700 1400 3700

Text Label 1200 3700 0    50   ~ 0
B21

Wire Wire Line
	1200 3800 1400 3800

Text Label 1200 3800 0    50   ~ 0
3V3

Wire Wire Line
	1200 3900 1400 3900

Text Label 1200 3900 0    50   ~ 0
B17

Wire Wire Line
	1200 4000 1400 4000

Text Label 1200 4000 0    50   ~ 0
A17

Wire Wire Line
	1200 4100 1400 4100

Text Label 1200 4100 0    50   ~ 0
A02

Wire Wire Line
	1200 4200 1400 4200

Text Label 1200 4200 0    50   ~ 0
A22

Wire Wire Line
	1200 4300 1400 4300

Text Label 1200 4300 0    50   ~ 0
A14

Wire Wire Line
	1200 4400 1400 4400

Text Label 1200 4400 0    50   ~ 0
B24

Wire Wire Line
	1200 4500 1400 4500

Text Label 1200 4500 0    50   ~ 0
B20

Wire Wire Line
	1200 4600 1400 4600

Text Label 1200 4600 0    50   ~ 0
A26

Wire Wire Line
	1200 4700 1400 4700

Text Label 1200 4700 0    50   ~ 0
A25

Wire Wire Line
	1200 4800 1400 4800

Text Label 1200 4800 0    50   ~ 0
A24

Wire Wire Line
	1200 4900 1400 4900

Text Label 1200 4900 0    50   ~ 0
B25

Wire Wire Line
	1200 5000 1400 5000

Text Label 1200 5000 0    50   ~ 0
GND

Wire Wire Line
	1200 5100 1400 5100

Text Label 1200 5100 0    50   ~ 0
A27

Wire Wire Line
	1200 5200 1400 5200

Text Label 1200 5200 0    50   ~ 0
5V

Wire Wire Line
	1200 5300 1400 5300

Text Label 1200 5300 0    50   ~ 0
GND

Wire Wire Line
	1200 5400 1400 5400

Text Label 1200 5400 0    50   ~ 0
GND

$Comp
L TianMengXing:MODULE_40 U7
U 1 1 5F000002
P 4200 1450
F 0 "U7" H 4200 1230 50  0000 C CNN
F 1 "主控左侧扩展排针" H 4200 1670 50  0000 C CNN
F 2 "" H 4200 1450 50  0001 C CNN
F 3 "" H 4200 1450 50  0001 C CNN
	1    4200 1450
	1    0    0    -1
$EndComp

Wire Wire Line
	3700 -500 3900 -500

Text Label 3700 -500 0    50   ~ 0
A28

Wire Wire Line
	3700 -400 3900 -400

Text Label 3700 -400 0    50   ~ 0
A31

Wire Wire Line
	3700 -300 3900 -300

Text Label 3700 -300 0    50   ~ 0
B04

Wire Wire Line
	3700 -200 3900 -200

Text Label 3700 -200 0    50   ~ 0
B05

Wire Wire Line
	3700 -100 3900 -100

Text Label 3700 -100 0    50   ~ 0
A10

Wire Wire Line
	3700 0 3900 0

Text Label 3700 0 0    50   ~ 0
A11

Wire Wire Line
	3700 100 3900 100

Text Label 3700 100 0    50   ~ 0
B12

Wire Wire Line
	3700 200 3900 200

Text Label 3700 200 0    50   ~ 0
B13

Wire Wire Line
	3700 300 3900 300

Text Label 3700 300 0    50   ~ 0
VCC

Wire Wire Line
	3700 400 3900 400

Text Label 3700 400 0    50   ~ 0
+5V

Wire Wire Line
	3700 500 3900 500

Text Label 3700 500 0    50   ~ 0
B07

Wire Wire Line
	3700 600 3900 600

Text Label 3700 600 0    50   ~ 0
B09

Wire Wire Line
	3700 700 3900 700

Text Label 3700 700 0    50   ~ 0
A13

Wire Wire Line
	3700 800 3900 800

Text Label 3700 800 0    50   ~ 0
B26

Wire Wire Line
	3700 900 3900 900

Text Label 3700 900 0    50   ~ 0
A29

Wire Wire Line
	3700 1000 3900 1000

Text Label 3700 1000 0    50   ~ 0
CHIP

Wire Wire Line
	3700 1100 3900 1100

Text Label 3700 1100 0    50   ~ 0
3V3

Wire Wire Line
	3700 1200 3900 1200

Text Label 3700 1200 0    50   ~ 0
+5V

Wire Wire Line
	3700 1300 3900 1300

Text Label 3700 1300 0    50   ~ 0
GND

Wire Wire Line
	3700 1400 3900 1400

Text Label 3700 1400 0    50   ~ 0
GND

Wire Wire Line
	3700 1500 3900 1500

Text Label 3700 1500 0    50   ~ 0
A00

Wire Wire Line
	3700 1600 3900 1600

Text Label 3700 1600 0    50   ~ 0
A01

Wire Wire Line
	3700 1700 3900 1700

Text Label 3700 1700 0    50   ~ 0
A08

Wire Wire Line
	3700 1800 3900 1800

Text Label 3700 1800 0    50   ~ 0
A09

Wire Wire Line
	3700 1900 3900 1900

Text Label 3700 1900 0    50   ~ 0
B15

Wire Wire Line
	3700 2000 3900 2000

Text Label 3700 2000 0    50   ~ 0
B16

Wire Wire Line
	3700 2100 3900 2100

Text Label 3700 2100 0    50   ~ 0
B02

Wire Wire Line
	3700 2200 3900 2200

Text Label 3700 2200 0    50   ~ 0
B03

Wire Wire Line
	3700 2300 3900 2300

Text Label 3700 2300 0    50   ~ 0
DIO

Wire Wire Line
	3700 2400 3900 2400

Text Label 3700 2400 0    50   ~ 0
GND

Wire Wire Line
	3700 2500 3900 2500

Text Label 3700 2500 0    50   ~ 0
B06

Wire Wire Line
	3700 2600 3900 2600

Text Label 3700 2600 0    50   ~ 0
B08

Wire Wire Line
	3700 2700 3900 2700

Text Label 3700 2700 0    50   ~ 0
A12

Wire Wire Line
	3700 2800 3900 2800

Text Label 3700 2800 0    50   ~ 0
B23

Wire Wire Line
	3700 2900 3900 2900

Text Label 3700 2900 0    50   ~ 0
B27

Wire Wire Line
	3700 3000 3900 3000

Text Label 3700 3000 0    50   ~ 0
AGND

Wire Wire Line
	3700 3100 3900 3100

Text Label 3700 3100 0    50   ~ 0
GND

Wire Wire Line
	3700 3200 3900 3200

Text Label 3700 3200 0    50   ~ 0
GND

Wire Wire Line
	3700 3300 3900 3300

Text Label 3700 3300 0    50   ~ 0
GND

Wire Wire Line
	3700 3400 3900 3400

Text Label 3700 3400 0    50   ~ 0
GND

$Comp
L TianMengXing:MODULE_40 U8
U 1 1 5F000003
P 6400 1450
F 0 "U8" H 6400 1230 50  0000 C CNN
F 1 "主控右侧扩展排针" H 6400 1670 50  0000 C CNN
F 2 "" H 6400 1450 50  0001 C CNN
F 3 "" H 6400 1450 50  0001 C CNN
	1    6400 1450
	1    0    0    -1
$EndComp

Wire Wire Line
	5900 -500 6100 -500

Text Label 5900 -500 0    50   ~ 0
A26

Wire Wire Line
	5900 -400 6100 -400

Text Label 5900 -400 0    50   ~ 0
A24

Wire Wire Line
	5900 -300 6100 -300

Text Label 5900 -300 0    50   ~ 0
B24

Wire Wire Line
	5900 -200 6100 -200

Text Label 5900 -200 0    50   ~ 0
A22

Wire Wire Line
	5900 -100 6100 -100

Text Label 5900 -100 0    50   ~ 0
A15

Wire Wire Line
	5900 0 6100 0

Text Label 5900 0 0    50   ~ 0
A17

Wire Wire Line
	5900 100 6100 100

Text Label 5900 100 0    50   ~ 0
B18

Wire Wire Line
	5900 200 6100 200

Text Label 5900 200 0    50   ~ 0
A21

Wire Wire Line
	5900 300 6100 300

Text Label 5900 300 0    50   ~ 0
A23

Wire Wire Line
	5900 400 6100 400

Text Label 5900 400 0    50   ~ 0
VCC

Wire Wire Line
	5900 500 6100 500

Text Label 5900 500 0    50   ~ 0
+5V

Wire Wire Line
	5900 600 6100 600

Text Label 5900 600 0    50   ~ 0
B22

Wire Wire Line
	5900 700 6100 700

Text Label 5900 700 0    50   ~ 0
B01

Wire Wire Line
	5900 800 6100 800

Text Label 5900 800 0    50   ~ 0
A07

Wire Wire Line
	5900 900 6100 900

Text Label 5900 900 0    50   ~ 0
B14

Wire Wire Line
	5900 1000 6100 1000

Text Label 5900 1000 0    50   ~ 0
A18

Wire Wire Line
	5900 1100 6100 1100

Text Label 5900 1100 0    50   ~ 0
3V3

Wire Wire Line
	5900 1200 6100 1200

Text Label 5900 1200 0    50   ~ 0
+5V

Wire Wire Line
	5900 1300 6100 1300

Text Label 5900 1300 0    50   ~ 0
GND

Wire Wire Line
	5900 1400 6100 1400

Text Label 5900 1400 0    50   ~ 0
GND

Wire Wire Line
	5900 1500 6100 1500

Text Label 5900 1500 0    50   ~ 0
A27

Wire Wire Line
	5900 1600 6100 1600

Text Label 5900 1600 0    50   ~ 0
A25

Wire Wire Line
	5900 1700 6100 1700

Text Label 5900 1700 0    50   ~ 0
B25

Wire Wire Line
	5900 1800 6100 1800

Text Label 5900 1800 0    50   ~ 0
B20

Wire Wire Line
	5900 1900 6100 1900

Text Label 5900 1900 0    50   ~ 0
A14

Wire Wire Line
	5900 2000 6100 2000

Text Label 5900 2000 0    50   ~ 0
A16

Wire Wire Line
	5900 2100 6100 2100

Text Label 5900 2100 0    50   ~ 0
B17

Wire Wire Line
	5900 2200 6100 2200

Text Label 5900 2200 0    50   ~ 0
B19

Wire Wire Line
	5900 2300 6100 2300

Text Label 5900 2300 0    50   ~ 0
A02

Wire Wire Line
	5900 2400 6100 2400

Text Label 5900 2400 0    50   ~ 0
B21

Wire Wire Line
	5900 2500 6100 2500

Text Label 5900 2500 0    50   ~ 0
A30

Wire Wire Line
	5900 2600 6100 2600

Text Label 5900 2600 0    50   ~ 0
B00

Wire Wire Line
	5900 2700 6100 2700

Text Label 5900 2700 0    50   ~ 0
B10

Wire Wire Line
	5900 2800 6100 2800

Text Label 5900 2800 0    50   ~ 0
B11

Wire Wire Line
	5900 2900 6100 2900

Text Label 5900 2900 0    50   ~ 0
RST

Wire Wire Line
	5900 3000 6100 3000

Text Label 5900 3000 0    50   ~ 0
GND

Wire Wire Line
	5900 3100 6100 3100

Text Label 5900 3100 0    50   ~ 0
GND

Wire Wire Line
	5900 3200 6100 3200

Text Label 5900 3200 0    50   ~ 0
GND

Wire Wire Line
	5900 3300 6100 3300

Text Label 5900 3300 0    50   ~ 0
GND

Wire Wire Line
	5900 3400 6100 3400

Text Label 5900 3400 0    50   ~ 0
GND

Text Notes 8800 450 0    100  ~ 0
12V供电 / 电源模块

$Comp
L TianMengXing:CONN_01X02 P1
U 1 1 5F000004
P 9300 800
F 0 "P1" H 9300 580 50  0000 C CNN
F 1 "WJ500V-5.08-2P 12V输入" H 9300 1020 50  0000 C CNN
F 2 "" H 9300 800 50  0001 C CNN
F 3 "" H 9300 800 50  0001 C CNN
	1    9300 800
	1    0    0    -1
$EndComp

Wire Wire Line
	8800 750 9000 750

Text Label 8800 750 0    50   ~ 0
VM_RAW

Wire Wire Line
	8800 850 9000 850

Text Label 8800 850 0    50   ~ 0
GND

$Comp
L TianMengXing:SW_SPDT SW1
U 1 1 5F000005
P 10800 800
F 0 "SW1" H 10800 580 50  0000 C CNN
F 1 "SS-12D11G5R 开关" H 10800 1020 50  0000 C CNN
F 2 "" H 10800 800 50  0001 C CNN
F 3 "" H 10800 800 50  0001 C CNN
	1    10800 800
	1    0    0    -1
$EndComp

Wire Wire Line
	10300 600 10500 600

Text Label 10300 600 0    50   ~ 0
GND

Wire Wire Line
	10300 700 10500 700

Text Label 10300 700 0    50   ~ 0
VM

Wire Wire Line
	10300 900 10500 900

Text Label 10300 900 0    50   ~ 0
VM_RAW

Wire Wire Line
	10300 1000 10500 1000

Text Label 10300 1000 0    50   ~ 0
GND

$Comp
L TianMengXing:MODULE_14 U5
U 1 1 5F000006
P 12200 1050
F 0 "U5" H 12200 830 50  0000 C CNN
F 1 "电源模块 5V/3V3" H 12200 1270 50  0000 C CNN
F 2 "" H 12200 1050 50  0001 C CNN
F 3 "" H 12200 1050 50  0001 C CNN
	1    12200 1050
	1    0    0    -1
$EndComp

Wire Wire Line
	11700 400 11900 400

Text Label 11700 400 0    50   ~ 0
+5V

Wire Wire Line
	11700 500 11900 500

Text Label 11700 500 0    50   ~ 0
+5V

Wire Wire Line
	11700 600 11900 600

Text Label 11700 600 0    50   ~ 0
GND

Wire Wire Line
	11700 700 11900 700

Text Label 11700 700 0    50   ~ 0
GND

Wire Wire Line
	11700 800 11900 800

Text Label 11700 800 0    50   ~ 0
GND

Wire Wire Line
	11700 900 11900 900

Text Label 11700 900 0    50   ~ 0
GND

Wire Wire Line
	11700 1000 11900 1000

Text Label 11700 1000 0    50   ~ 0
3V3

Wire Wire Line
	11700 1100 11900 1100

Text Label 11700 1100 0    50   ~ 0
3V3

Wire Wire Line
	11700 1200 11900 1200

Text Label 11700 1200 0    50   ~ 0
VM

Wire Wire Line
	11700 1300 11900 1300

Text Label 11700 1300 0    50   ~ 0
VM

Wire Wire Line
	11700 1400 11900 1400

Text Label 11700 1400 0    50   ~ 0
VM

Wire Wire Line
	11700 1500 11900 1500

Text Label 11700 1500 0    50   ~ 0
GND

Wire Wire Line
	11700 1600 11900 1600

Text Label 11700 1600 0    50   ~ 0
GND

Wire Wire Line
	11700 1700 11900 1700

Text Label 11700 1700 0    50   ~ 0
GND

Text Notes 8800 2350 0    100  ~ 0
蜂鸣器 / LED / 按键

$Comp
L TianMengXing:BUZZER BUZZER1
U 1 1 5F000007
P 9300 2800
F 0 "BUZZER1" H 9300 2580 50  0000 C CNN
F 1 "3kHz" H 9300 3020 50  0000 C CNN
F 2 "" H 9300 2800 50  0001 C CNN
F 3 "" H 9300 2800 50  0001 C CNN
	1    9300 2800
	1    0    0    -1
$EndComp

Wire Wire Line
	8800 2750 9000 2750

Text Label 8800 2750 0    50   ~ 0
+5V

Wire Wire Line
	8800 2850 9000 2850

Text Label 8800 2850 0    50   ~ 0
BUZZER_SW

$Comp
L TianMengXing:MOS_N Q1
U 1 1 5F000008
P 10500 2800
F 0 "Q1" H 10500 2580 50  0000 C CNN
F 1 "SI2302" H 10500 3020 50  0000 C CNN
F 2 "" H 10500 2800 50  0001 C CNN
F 3 "" H 10500 2800 50  0001 C CNN
	1    10500 2800
	1    0    0    -1
$EndComp

Wire Wire Line
	10000 2700 10200 2700

Text Label 10000 2700 0    50   ~ 0
BUZZER_SW

Wire Wire Line
	10000 2800 10200 2800

Text Label 10000 2800 0    50   ~ 0
B17

Wire Wire Line
	10000 2900 10200 2900

Text Label 10000 2900 0    50   ~ 0
GND

$Comp
L TianMengXing:R R1
U 1 1 5F000009
P 11500 2800
F 0 "R1" H 11500 2580 50  0000 C CNN
F 1 "10K" H 11500 3020 50  0000 C CNN
F 2 "" H 11500 2800 50  0001 C CNN
F 3 "" H 11500 2800 50  0001 C CNN
	1    11500 2800
	1    0    0    -1
$EndComp

Wire Wire Line
	11000 2750 11200 2750

Text Label 11000 2750 0    50   ~ 0
B17

Wire Wire Line
	11000 2850 11200 2850

Text Label 11000 2850 0    50   ~ 0
GND

$Comp
L TianMengXing:R R2
U 1 1 5F00000A
P 9300 3650
F 0 "R2" H 9300 3430 50  0000 C CNN
F 1 "510" H 9300 3870 50  0000 C CNN
F 2 "" H 9300 3650 50  0001 C CNN
F 3 "" H 9300 3650 50  0001 C CNN
	1    9300 3650
	1    0    0    -1
$EndComp

Wire Wire Line
	8800 3600 9000 3600

Text Label 8800 3600 0    50   ~ 0
B27

Wire Wire Line
	8800 3700 9000 3700

Text Label 8800 3700 0    50   ~ 0
LED_A

$Comp
L TianMengXing:LED LED1
U 1 1 5F00000B
P 10500 3650
F 0 "LED1" H 10500 3430 50  0000 C CNN
F 1 "LED" H 10500 3870 50  0000 C CNN
F 2 "" H 10500 3650 50  0001 C CNN
F 3 "" H 10500 3650 50  0001 C CNN
	1    10500 3650
	1    0    0    -1
$EndComp

Wire Wire Line
	10000 3600 10200 3600

Text Label 10000 3600 0    50   ~ 0
LED_A

Wire Wire Line
	10000 3700 10200 3700

Text Label 10000 3700 0    50   ~ 0
3V3

$Comp
L TianMengXing:CONN_01X02 K2
U 1 1 5F00000C
P 11600 3600
F 0 "K2" H 11600 3380 50  0000 C CNN
F 1 "按键 A25" H 11600 3820 50  0000 C CNN
F 2 "" H 11600 3600 50  0001 C CNN
F 3 "" H 11600 3600 50  0001 C CNN
	1    11600 3600
	1    0    0    -1
$EndComp

Wire Wire Line
	11100 3550 11300 3550

Text Label 11100 3550 0    50   ~ 0
A25

Wire Wire Line
	11100 3650 11300 3650

Text Label 11100 3650 0    50   ~ 0
GND

$Comp
L TianMengXing:CONN_01X02 K1
U 1 1 5F00000D
P 12800 3600
F 0 "K1" H 12800 3380 50  0000 C CNN
F 1 "按键 A26" H 12800 3820 50  0000 C CNN
F 2 "" H 12800 3600 50  0001 C CNN
F 3 "" H 12800 3600 50  0001 C CNN
	1    12800 3600
	1    0    0    -1
$EndComp

Wire Wire Line
	12300 3550 12500 3550

Text Label 12300 3550 0    50   ~ 0
A26

Wire Wire Line
	12300 3650 12500 3650

Text Label 12300 3650 0    50   ~ 0
GND

Text Notes 8800 4800 0    100  ~ 0
TB6612 / 电机

$Comp
L TianMengXing:TB6612_AB U_TB1
U 1 1 5F00000E
P 9400 5600
F 0 "U_TB1" H 9400 5380 50  0000 C CNN
F 1 "TB6612-AB" H 9400 5820 50  0000 C CNN
F 2 "" H 9400 5600 50  0001 C CNN
F 3 "" H 9400 5600 50  0001 C CNN
	1    9400 5600
	1    0    0    -1
$EndComp

Wire Wire Line
	8900 4850 9100 4850

Text Label 8900 4850 0    50   ~ 0
B15

Wire Wire Line
	8900 4950 9100 4950

Text Label 8900 4950 0    50   ~ 0
A12

Wire Wire Line
	8900 5050 9100 5050

Text Label 8900 5050 0    50   ~ 0
A13

Wire Wire Line
	8900 5150 9100 5150

Text Label 8900 5150 0    50   ~ 0
VCC

Wire Wire Line
	8900 5250 9100 5250

Text Label 8900 5250 0    50   ~ 0
B00

Wire Wire Line
	8900 5350 9100 5350

Text Label 8900 5350 0    50   ~ 0
B01

Wire Wire Line
	8900 5450 9100 5450

Text Label 8900 5450 0    50   ~ 0
B16

Wire Wire Line
	8900 5550 9100 5550

Text Label 8900 5550 0    50   ~ 0
GND

Wire Wire Line
	8900 5650 9100 5650

Text Label 8900 5650 0    50   ~ 0
VM

Wire Wire Line
	8900 5750 9100 5750

Text Label 8900 5750 0    50   ~ 0
+5V

Wire Wire Line
	8900 5850 9100 5850

Text Label 8900 5850 0    50   ~ 0
GND

Wire Wire Line
	8900 5950 9100 5950

Text Label 8900 5950 0    50   ~ 0
AO1

Wire Wire Line
	8900 6050 9100 6050

Text Label 8900 6050 0    50   ~ 0
AO2

Wire Wire Line
	8900 6150 9100 6150

Text Label 8900 6150 0    50   ~ 0
BO2

Wire Wire Line
	8900 6250 9100 6250

Text Label 8900 6250 0    50   ~ 0
BO1

Wire Wire Line
	8900 6350 9100 6350

Text Label 8900 6350 0    50   ~ 0
GND

$Comp
L TianMengXing:CONN_01X06 J_MA
U 1 1 5F00000F
P 11800 5200
F 0 "J_MA" H 11800 4980 50  0000 C CNN
F 1 "Motor-A BX-XH2.54-6PWZ" H 11800 5420 50  0000 C CNN
F 2 "" H 11800 5200 50  0001 C CNN
F 3 "" H 11800 5200 50  0001 C CNN
	1    11800 5200
	1    0    0    -1
$EndComp

Wire Wire Line
	11300 4950 11500 4950

Text Label 11300 4950 0    50   ~ 0
AO1

Wire Wire Line
	11300 5050 11500 5050

Text Label 11300 5050 0    50   ~ 0
GND

Wire Wire Line
	11300 5150 11500 5150

Text Label 11300 5150 0    50   ~ 0
A15

Wire Wire Line
	11300 5250 11500 5250

Text Label 11300 5250 0    50   ~ 0
A16

Wire Wire Line
	11300 5350 11500 5350

Text Label 11300 5350 0    50   ~ 0
AO2

Wire Wire Line
	11300 5450 11500 5450

Text Label 11300 5450 0    50   ~ 0
+5V

$Comp
L TianMengXing:CONN_01X06 J_MB
U 1 1 5F000010
P 11800 6300
F 0 "J_MB" H 11800 6080 50  0000 C CNN
F 1 "Motor-B BX-XH2.54-6PWZ" H 11800 6520 50  0000 C CNN
F 2 "" H 11800 6300 50  0001 C CNN
F 3 "" H 11800 6300 50  0001 C CNN
	1    11800 6300
	1    0    0    -1
$EndComp

Wire Wire Line
	11300 6050 11500 6050

Text Label 11300 6050 0    50   ~ 0
BO2

Wire Wire Line
	11300 6150 11500 6150

Text Label 11300 6150 0    50   ~ 0
GND

Wire Wire Line
	11300 6250 11500 6250

Text Label 11300 6250 0    50   ~ 0
A17

Wire Wire Line
	11300 6350 11500 6350

Text Label 11300 6350 0    50   ~ 0
A24

Wire Wire Line
	11300 6450 11500 6450

Text Label 11300 6450 0    50   ~ 0
BO1

Wire Wire Line
	11300 6550 11500 6550

Text Label 11300 6550 0    50   ~ 0
+5V

$Comp
L TianMengXing:C C1
U 1 1 5F000011
P 13600 5200
F 0 "C1" H 13600 4980 50  0000 C CNN
F 1 "0.1uF Motor-B" H 13600 5420 50  0000 C CNN
F 2 "" H 13600 5200 50  0001 C CNN
F 3 "" H 13600 5200 50  0001 C CNN
	1    13600 5200
	1    0    0    -1
$EndComp

Wire Wire Line
	13100 5150 13300 5150

Text Label 13100 5150 0    50   ~ 0
+5V

Wire Wire Line
	13100 5250 13300 5250

Text Label 13100 5250 0    50   ~ 0
GND

$Comp
L TianMengXing:C C2
U 1 1 5F000012
P 13600 6300
F 0 "C2" H 13600 6080 50  0000 C CNN
F 1 "0.1uF Motor-A" H 13600 6520 50  0000 C CNN
F 2 "" H 13600 6300 50  0001 C CNN
F 3 "" H 13600 6300 50  0001 C CNN
	1    13600 6300
	1    0    0    -1
$EndComp

Wire Wire Line
	13100 6250 13300 6250

Text Label 13100 6250 0    50   ~ 0
+5V

Wire Wire Line
	13100 6350 13300 6350

Text Label 13100 6350 0    50   ~ 0
GND

Text Notes 700 7200 0    100  ~ 0
外设接口

$Comp
L TianMengXing:CONN_01X04 J_US1
U 1 1 5F000013
P 1400 7700
F 0 "J_US1" H 1400 7480 50  0000 C CNN
F 1 "HC-SR04 超声波" H 1400 7920 50  0000 C CNN
F 2 "" H 1400 7700 50  0001 C CNN
F 3 "" H 1400 7700 50  0001 C CNN
	1    1400 7700
	1    0    0    -1
$EndComp

Wire Wire Line
	900 7550 1100 7550

Text Label 900 7550 0    50   ~ 0
+5V

Wire Wire Line
	900 7650 1100 7650

Text Label 900 7650 0    50   ~ 0
A08

Wire Wire Line
	900 7750 1100 7750

Text Label 900 7750 0    50   ~ 0
A09

Wire Wire Line
	900 7850 1100 7850

Text Label 900 7850 0    50   ~ 0
GND

$Comp
L TianMengXing:CONN_01X04 J_BT1
U 1 1 5F000014
P 3000 7700
F 0 "J_BT1" H 3000 7480 50  0000 C CNN
F 1 "2-TX1-RX 蓝牙" H 3000 7920 50  0000 C CNN
F 2 "" H 3000 7700 50  0001 C CNN
F 3 "" H 3000 7700 50  0001 C CNN
	1    3000 7700
	1    0    0    -1
$EndComp

Wire Wire Line
	2500 7550 2700 7550

Text Label 2500 7550 0    50   ~ 0
B06

Wire Wire Line
	2500 7650 2700 7650

Text Label 2500 7650 0    50   ~ 0
B07

Wire Wire Line
	2500 7750 2700 7750

Text Label 2500 7750 0    50   ~ 0
GND

Wire Wire Line
	2500 7850 2700 7850

Text Label 2500 7850 0    50   ~ 0
+5V

$Comp
L TianMengXing:CONN_01X04 J_CAM1
U 1 1 5F000015
P 4600 7700
F 0 "J_CAM1" H 4600 7480 50  0000 C CNN
F 1 "1-TX2-RX 摄像头" H 4600 7920 50  0000 C CNN
F 2 "" H 4600 7700 50  0001 C CNN
F 3 "" H 4600 7700 50  0001 C CNN
	1    4600 7700
	1    0    0    -1
$EndComp

Wire Wire Line
	4100 7550 4300 7550

Text Label 4100 7550 0    50   ~ 0
B03

Wire Wire Line
	4100 7650 4300 7650

Text Label 4100 7650 0    50   ~ 0
B02

Wire Wire Line
	4100 7750 4300 7750

Text Label 4100 7750 0    50   ~ 0
GND

Wire Wire Line
	4100 7850 4300 7850

Text Label 4100 7850 0    50   ~ 0
+5V

$Comp
L TianMengXing:CONN_01X04 OLED1
U 1 1 5F000016
P 6200 7700
F 0 "OLED1" H 6200 7480 50  0000 C CNN
F 1 "HS96L03W2C03 OLED" H 6200 7920 50  0000 C CNN
F 2 "" H 6200 7700 50  0001 C CNN
F 3 "" H 6200 7700 50  0001 C CNN
	1    6200 7700
	1    0    0    -1
$EndComp

Wire Wire Line
	5700 7550 5900 7550

Text Label 5700 7550 0    50   ~ 0
GND

Wire Wire Line
	5700 7650 5900 7650

Text Label 5700 7650 0    50   ~ 0
VCC

Wire Wire Line
	5700 7750 5900 7750

Text Label 5700 7750 0    50   ~ 0
A31

Wire Wire Line
	5700 7850 5900 7850

Text Label 5700 7850 0    50   ~ 0
A28

$Comp
L TianMengXing:CONN_01X03 SERVO1
U 1 1 5F000017
P 7800 7500
F 0 "SERVO1" H 7800 7280 50  0000 C CNN
F 1 "舵机1" H 7800 7720 50  0000 C CNN
F 2 "" H 7800 7500 50  0001 C CNN
F 3 "" H 7800 7500 50  0001 C CNN
	1    7800 7500
	1    0    0    -1
$EndComp

Wire Wire Line
	7300 7400 7500 7400

Text Label 7300 7400 0    50   ~ 0
B09

Wire Wire Line
	7300 7500 7500 7500

Text Label 7300 7500 0    50   ~ 0
+5V

Wire Wire Line
	7300 7600 7500 7600

Text Label 7300 7600 0    50   ~ 0
GND

$Comp
L TianMengXing:CONN_01X03 SERVO2
U 1 1 5F000018
P 9200 7500
F 0 "SERVO2" H 9200 7280 50  0000 C CNN
F 1 "舵机2" H 9200 7720 50  0000 C CNN
F 2 "" H 9200 7500 50  0001 C CNN
F 3 "" H 9200 7500 50  0001 C CNN
	1    9200 7500
	1    0    0    -1
$EndComp

Wire Wire Line
	8700 7400 8900 7400

Text Label 8700 7400 0    50   ~ 0
B08

Wire Wire Line
	8700 7500 8900 7500

Text Label 8700 7500 0    50   ~ 0
+5V

Wire Wire Line
	8700 7600 8900 7600

Text Label 8700 7600 0    50   ~ 0
GND

$Comp
L TianMengXing:CONN_01X10 J_TRACK1
U 1 1 5F000019
P 11000 7800
F 0 "J_TRACK1" H 11000 7580 50  0000 C CNN
F 1 "循迹 10P" H 11000 8020 50  0000 C CNN
F 2 "" H 11000 7800 50  0001 C CNN
F 3 "" H 11000 7800 50  0001 C CNN
	1    11000 7800
	1    0    0    -1
$EndComp

Wire Wire Line
	10500 7350 10700 7350

Text Label 10500 7350 0    50   ~ 0
+5V

Wire Wire Line
	10500 7450 10700 7450

Text Label 10500 7450 0    50   ~ 0
GND

Wire Wire Line
	10500 7550 10700 7550

Text Label 10500 7550 0    50   ~ 0
B25

Wire Wire Line
	10500 7650 10700 7650

Text Label 10500 7650 0    50   ~ 0
B24

Wire Wire Line
	10500 7750 10700 7750

Text Label 10500 7750 0    50   ~ 0
B20

Wire Wire Line
	10500 7850 10700 7850

Text Label 10500 7850 0    50   ~ 0
A14

Wire Wire Line
	10500 7950 10700 7950

Text Label 10500 7950 0    50   ~ 0
B18

Wire Wire Line
	10500 8050 10700 8050

Text Label 10500 8050 0    50   ~ 0
B19

Wire Wire Line
	10500 8150 10700 8150

Text Label 10500 8150 0    50   ~ 0
B10

Wire Wire Line
	10500 8250 10700 8250

Text Label 10500 8250 0    50   ~ 0
A07

Text Notes 700 9900 0    100  ~ 0
陀螺仪 / I2C

$Comp
L TianMengXing:MODULE_17 U9
U 1 1 5F00001A
P 1600 10600
F 0 "U9" H 1600 10380 50  0000 C CNN
F 1 "陀螺仪模块" H 1600 10820 50  0000 C CNN
F 2 "" H 1600 10600 50  0001 C CNN
F 3 "" H 1600 10600 50  0001 C CNN
	1    1600 10600
	1    0    0    -1
$EndComp

Wire Wire Line
	1100 9800 1300 9800

Text Label 1100 9800 0    50   ~ 0
+5V

Wire Wire Line
	1100 9900 1300 9900

Text Label 1100 9900 0    50   ~ 0
A01

Wire Wire Line
	1100 10000 1300 10000

Text Label 1100 10000 0    50   ~ 0
A00

Wire Wire Line
	1100 10100 1300 10100

Text Label 1100 10100 0    50   ~ 0
GND

Wire Wire Line
	1100 10200 1300 10200

Text Label 1100 10200 0    50   ~ 0
+5V

Wire Wire Line
	1100 10500 1300 10500

Text Label 1100 10500 0    50   ~ 0
A11

Wire Wire Line
	1100 10600 1300 10600

Text Label 1100 10600 0    50   ~ 0
A11

Wire Wire Line
	1100 10700 1300 10700

Text Label 1100 10700 0    50   ~ 0
A10

Wire Wire Line
	1100 10800 1300 10800

Text Label 1100 10800 0    50   ~ 0
GND

Wire Wire Line
	1100 11000 1300 11000

Text Label 1100 11000 0    50   ~ 0
3V3

Wire Wire Line
	1100 11100 1300 11100

Text Label 1100 11100 0    50   ~ 0
GND

Wire Wire Line
	1100 11200 1300 11200

Text Label 1100 11200 0    50   ~ 0
A11

Wire Wire Line
	1100 11300 1300 11300

Text Label 1100 11300 0    50   ~ 0
A10

$Comp
L TianMengXing:R R4
U 1 1 5F00001B
P 3600 10300
F 0 "R4" H 3600 10080 50  0000 C CNN
F 1 "4.7K" H 3600 10520 50  0000 C CNN
F 2 "" H 3600 10300 50  0001 C CNN
F 3 "" H 3600 10300 50  0001 C CNN
	1    3600 10300
	1    0    0    -1
$EndComp

Wire Wire Line
	3100 10250 3300 10250

Text Label 3100 10250 0    50   ~ 0
VCC

Wire Wire Line
	3100 10350 3300 10350

Text Label 3100 10350 0    50   ~ 0
A11

$Comp
L TianMengXing:R R5
U 1 1 5F00001C
P 3600 11000
F 0 "R5" H 3600 10780 50  0000 C CNN
F 1 "4.7K" H 3600 11220 50  0000 C CNN
F 2 "" H 3600 11000 50  0001 C CNN
F 3 "" H 3600 11000 50  0001 C CNN
	1    3600 11000
	1    0    0    -1
$EndComp

Wire Wire Line
	3100 10950 3300 10950

Text Label 3100 10950 0    50   ~ 0
VCC

Wire Wire Line
	3100 11050 3300 11050

Text Label 3100 11050 0    50   ~ 0
A10

Text Notes 7000 9900 0    100  ~ 0
供电桩 / 固定孔

$Comp
L TianMengXing:CONN_02X06 J_PWR1
U 1 1 5F00001D
P 7600 10600
F 0 "J_PWR1" H 7600 10380 50  0000 C CNN
F 1 "电桩 2x6" H 7600 10820 50  0000 C CNN
F 2 "" H 7600 10600 50  0001 C CNN
F 3 "" H 7600 10600 50  0001 C CNN
	1    7600 10600
	1    0    0    -1
$EndComp

Wire Wire Line
	7100 10050 7300 10050

Text Label 7100 10050 0    50   ~ 0
+5V

Wire Wire Line
	7100 10150 7300 10150

Text Label 7100 10150 0    50   ~ 0
+5V

Wire Wire Line
	7100 10250 7300 10250

Text Label 7100 10250 0    50   ~ 0
GND

Wire Wire Line
	7100 10350 7300 10350

Text Label 7100 10350 0    50   ~ 0
GND

Wire Wire Line
	7100 10450 7300 10450

Text Label 7100 10450 0    50   ~ 0
GND

Wire Wire Line
	7100 10550 7300 10550

Text Label 7100 10550 0    50   ~ 0
GND

Wire Wire Line
	7100 10650 7300 10650

Text Label 7100 10650 0    50   ~ 0
VCC

Wire Wire Line
	7100 10750 7300 10750

Text Label 7100 10750 0    50   ~ 0
VCC

Wire Wire Line
	7100 10850 7300 10850

Text Label 7100 10850 0    50   ~ 0
GND

Wire Wire Line
	7100 10950 7300 10950

Text Label 7100 10950 0    50   ~ 0
GND

Wire Wire Line
	7100 11050 7300 11050

Text Label 7100 11050 0    50   ~ 0
VCC

Wire Wire Line
	7100 11150 7300 11150

Text Label 7100 11150 0    50   ~ 0
VCC

$Comp
L TianMengXing:CONN_01X02 SCREW1
U 1 1 5F00001E
P 9400 10100
F 0 "SCREW1" H 9400 9880 50  0000 C CNN
F 1 "固定孔" H 9400 10320 50  0000 C CNN
F 2 "" H 9400 10100 50  0001 C CNN
F 3 "" H 9400 10100 50  0001 C CNN
	1    9400 10100
	1    0    0    -1
$EndComp

$Comp
L TianMengXing:CONN_01X02 SCREW2
U 1 1 5F00001F
P 10400 10100
F 0 "SCREW2" H 10400 9880 50  0000 C CNN
F 1 "固定孔" H 10400 10320 50  0000 C CNN
F 2 "" H 10400 10100 50  0001 C CNN
F 3 "" H 10400 10100 50  0001 C CNN
	1    10400 10100
	1    0    0    -1
$EndComp

$Comp
L TianMengXing:CONN_01X02 SCREW3
U 1 1 5F000020
P 11400 10100
F 0 "SCREW3" H 11400 9880 50  0000 C CNN
F 1 "固定孔" H 11400 10320 50  0000 C CNN
F 2 "" H 11400 10100 50  0001 C CNN
F 3 "" H 11400 10100 50  0001 C CNN
	1    11400 10100
	1    0    0    -1
$EndComp

$Comp
L TianMengXing:CONN_01X02 SCREW4
U 1 1 5F000021
P 12400 10100
F 0 "SCREW4" H 12400 9880 50  0000 C CNN
F 1 "固定孔" H 12400 10320 50  0000 C CNN
F 2 "" H 12400 10100 50  0001 C CNN
F 3 "" H 12400 10100 50  0001 C CNN
	1    12400 10100
	1    0    0    -1
$EndComp

$Comp
L TianMengXing:CONN_01X02 SCREW6
U 1 1 5F000022
P 13400 10100
F 0 "SCREW6" H 13400 9880 50  0000 C CNN
F 1 "固定孔" H 13400 10320 50  0000 C CNN
F 2 "" H 13400 10100 50  0001 C CNN
F 3 "" H 13400 10100 50  0001 C CNN
	1    13400 10100
	1    0    0    -1
$EndComp

$EndSCHEMATC
